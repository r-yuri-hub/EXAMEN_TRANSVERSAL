peliculas = {
    'P101': ['Luz de Otoño', 'DRAMA', 110, 'B', 'ESPAÑOL', False],
    'P102': ['Noche Neon', 'ACCION', 125, 'C', 'INGLES', True ],
    'P103': ['PLaneta Agua', 'DOCUMENTAL', 90, 'A', 'ESPAÑOL', False],
    'P104': [ 'Risa Total', 'COMEDIA', 105, 'A', 'ESPAÑOL', True],
    'P105': ['Codigo Zero', ' THRILLER', 118, 'C', 'INGLES', True],
    'P106': ['Viaje Lunar', ' CIENCIA FICCION', 132, 'B', 'INGLES', False]
}

cartelera = {
    'P101': [5990, 40],
    'P102': [7990, 0],
    'P103': [4990, 25],
    'P104': [6990, 12],
    'P105': [8890, 8],
    'P106': [7490, 3]
}


def leer_opcion():
    try:
        opcion = int(input("Ingrecse opción: "))
        if 1 <= opcion <= 6:
            return opcion
        else:
            return -1
    except ValueError:
        return -1


def cupos_genero(genero, dict_pelis, dict_cartelera):
    total_cupos = 0
    genero_buscado = genero.strip().upper()
    
    for codigo, datos in dict_pelis.items():
        genero_pelicula = datos[1].strip().upper()
        if genero_pelicula == genero_buscado:
            if codigo in dict_cartelera:
                total_cupos += dict_cartelera[codigo][1] 
                
    print(f"El total de cupos diponibles es:: {total_cupos}")


def busqueda_precio(p_min, p_max, dict_pelis, dict_cartelera):
    resultados = []
    for codigo, datos_cartelera in dict_cartelera.items():
        precio = datos_cartelera[0]
        cupos = datos_cartelera[1]
        
        if p_min <= precio <= p_max and cupos > 0:
            if codigo in dict_pelis:
                titulo = dict_pelis[codigo][0]
                resultados.append(f"{titulo}--{codigo}")
                
    if resultados:
     
        resultados.sort()
        print(f"Las películas encotradas son: {resultados}")
    else:
        print("No hay películas en e rango de precios.")


def buscar_codigo(codigo, dict_cartelera):
    return codigo.upper() in dict_cartelera

def actualizar_precio(codigo, nuevo_precio, dict_cartelera):
    cod_upper = codigo.upper()
    if buscar_codigo(cod_upper, dict_cartelera):
        dict_cartelera[cod_upper][0] = nuevo_precio
        return True
    return False

def eliminar_pelicula(codigo, dict_pelis, dict_cartelera):
    cod_upper = codigo.upper()
    if buscar_codigo(cod_upper, dict_cartelera):
        del dict_pelis[cod_upper]
        del dict_cartelera[cod_upper]
        return True
    return False


def validar_codigo(codigo, dict_cartelera):
    return codigo.strip() != "" and codigo.upper() not in dict_cartelera

def validar_texto(texto):
    return texto.strip() != ""

def validar_duracion(duracion):
    return duracion > 0

def validar_clasificacion(clasificacion):
    return clasificacion.upper() in ['A', 'B', 'C']

def validar_precio(precio):
    return precio > 0

def validar_cupos(cupos):
    return cupos >= 0

def agregar_pelicula(codigo, titulo, genero, duracion, clasificacion, idioma, es_3d, precio, cupos, dict_pelis, dict_cartelera):
    cod_upper = codigo.upper()
    if cod_upper in dict_cartelera:
        return False
    
 
    dict_pelis[cod_upper] = [titulo, genero.upper(), duracion, clasificacion.upper(), idioma.upper(), es_3d]
    
    dict_cartelera[cod_upper] = [precio, cupos]
    return True

#Pa invocar el menu pricipal
def main():
    while True:
        print("\n========== MENÚ PRINCIPAL ==========")
        print("1. Cupos por genero")
        print("2. Busqueda de peliculas por rango de precio")
        print("3. Actualizar precio de pelicula,")
        print("4. Agregar pelicula")
        print("5. Eliminar pelicla")
        print("6. Salir")
        print("=====================================")
        
        opcion = leer_opcion()
        
        if opcion == -1:
            print("Debe seleccionar una opción válida")
            continue
            
        if opcion == 1:
            print ("1.Accion")
            print ("2.Drama")
            print ("3.Comedia")
            print ("4.Documental")
            print ("5.Thriller")
            print ("6.Ciencia Ficcion")
            gen = input("Ingrese el genero a ver: ")

            cupos_genero(gen, peliculas, cartelera)
            
        elif opcion == 2:
            while True:
                try:
                    p_min = int(input("Ingrese precio mínimo: "))
                    p_max = int(input("Ingrese precio máximo: "))
                    if p_min >= 0 and p_max >= 0 and p_min <= p_max:
                        busqueda_precio(p_min, p_max, peliculas, cartelera)
                        break
                    else:
                        print("Los precios deben ser positivos y el mínimo menor o igual al máximo.")
                except ValueError:
                    print("Debe ingresar valores enteros")
                    
        elif opcion == 3:
            while True:
                cod = input("Ingrese código de película: ")
                try:
                    nuevo_p = int(input("Ingrese nuevo precio: "))
                    if nuevo_p > 0:
                        if actualizar_precio(cod, nuevo_p, cartelera):
                            print("Precio actualizado")
                        else:
                            print("El código no existe")
                    else:
                        print("El precio debe ser un entero positivo.")
                except ValueError:
                    print("Debe ingresar valores enteros para el precio")
                
                resp = input("¿Desea actualizar otro precio (s/n)?: ").lower()
                if resp != 's':
                    break
                    
        elif opcion == 4:
            cod = input("Ingrese código de película: ")
            if not validar_codigo(cod, cartelera):
                print("Código inválido o ya existente.")
                continue
                
            tit = input("Ingrese título: ")
            if not validar_texto(tit):
                print("Título no puede estar vacío.")
                continue
                
            gen = input("Ingrese género: ")
            if not validar_texto(gen):
                print("Género no puede estar vacío.")
                continue
                
            try:
                dur = int(input("Ingrese duración (minutos): "))
                if not validar_duracion(dur):
                    print("La duración debe ser mayor a cero.")
                    continue
            except ValueError:
                print("Debe ingresar un número entero.")
                continue
                
            clas = input("Ingrese clasificación (A, B o C): ")
            if not validar_clasificacion(clas):
                print("Clasificación incorrecta (Debe ser A, B o C).")
                continue
                
            idiom = input("Ingrese idioma: ")
            if not validar_texto(idiom):
                print("Idioma no puede estar vacío.")
                continue
                
            es_3d_input = input("¿Es 3D? (s/n): ").lower()
            if es_3d_input not in ['s', 'n']:
                print("Debe ingresar 's' o 'n'.")
                continue
            es_3d = True if es_3d_input == 's' else False
            
            try:
                prec = int(input("Ingrese precio: "))
                if not validar_precio(prec):
                    print("El precio debe ser mayor a cero.")
                    continue
            except ValueError:
                print("Debe ingresar un número entero.")
                continue
                
            try:
                cups = int(input("Ingrese cupos: "))
                if not validar_cupos(cups):
                    print("Los cupos no pueden ser negativos.")
                    continue
            except ValueError:
                print("Debe ingresar un número entero.")
                continue
                
            if agregar_pelicula(cod, tit, gen, dur, clas, idiom, es_3d, prec, cups, peliculas, cartelera):
                print("Película agregada")
            else:
                print("El código ya existe")
                
        elif opcion == 5:
            cod = input("Ingrese código de película a eliminar: ")
            if eliminar_pelicula(cod, peliculas, cartelera):
                print("Película eliminada")
            else:
                print("El código no existe")
                
        elif opcion == 6:
            print("Programa finalizado.")
            break

if __name__ == "__main__":
    main()